/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package patron_proxy_adapter;

/**
 *
 * @author maico
 */
public class OperacionDosAdaptador implements InterfazOperaciones {

    private OperacionDos objetodos;
    
    public OperacionDosAdaptador(){
        objetodos = new OperacionDos();
    }
    
    @Override
    public void operacion() {
        System.out.println("Adaptando");
        objetodos.operaciondos();
    }
    
}
