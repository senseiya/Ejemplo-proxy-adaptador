/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package patron_proxy_adapter;

/**
 *
 * @author maico
 */
public class Ejemplo_Proxy_Adaptador {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Proxy objetos = new Proxy();
        objetos.operacion();
    }
}
