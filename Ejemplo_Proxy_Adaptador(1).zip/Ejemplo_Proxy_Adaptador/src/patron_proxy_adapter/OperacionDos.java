/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package patron_proxy_adapter;

/**
 *
 * @author maico
 */
public class OperacionDos {
    
    public OperacionDos(){
        
    }
    
    public void operaciondos(){
        System.out.println("agregando musica");
        System.out.println("poniendo efectos especiales");
    }
}
