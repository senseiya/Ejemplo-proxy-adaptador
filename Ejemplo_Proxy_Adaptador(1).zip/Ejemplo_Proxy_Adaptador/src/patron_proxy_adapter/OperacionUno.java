/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package patron_proxy_adapter;

/**
 *
 * @author maico
 */
public class OperacionUno implements InterfazOperaciones {

    public OperacionUno(){
        
    }

    @Override
    public void operacion() {
        System.out.println("Creando un videojuego");
        System.out.println("agregando escenarios y mobs");
    }
}
